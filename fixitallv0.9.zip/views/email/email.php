<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
    <title>Wachtwoord reset</title>
</head>
<body>
<div>
    <div align="left">
        Er is een wachtwoord veranderen aanvraag gedaan voor het account:<br>
        <?= $result["username"] ?><br>
        Klik op de link hieronder om uw wachtwoord de veranderen:<br>
        <a href="http://localhost/windesheim/KBS-groep-2/views/login/forgot-password-reset.php?token=<?= $token ?>">http://localhost/windesheim/KBS-groep-2/views/login/forgot-password-reset</a>
    </div>
</div>
</body>
</html>