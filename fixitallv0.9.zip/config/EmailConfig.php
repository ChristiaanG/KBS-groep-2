<?php

/**
 * Created by PhpStorm.
 * User: Christiaan Goslinga
 * Date: 22-11-2017
 * Time: 15:55
 */
function emailConfig() {
    return array(      
        "username" => "email@gmail.com",
        "password" => "wachtwoord"
    );
}
