<?php

/**
 * Created by PhpStorm.
 * User: Christiaan Goslinga
 * Date: 22-11-2017
 * Time: 15:55
 */
function databaseConfig() {
    return array(
        "host" => "localhost",
        "username" => "root",
        "password" => "",
        "dbname" => "mydb2",
        "port" => 3306,
    );
}
