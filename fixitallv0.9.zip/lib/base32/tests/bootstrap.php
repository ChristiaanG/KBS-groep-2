<?php

$loader = require __DIR__ . '/../vendor/autoload.php';
$loader->add("Base32", __DIR__);
$loader->register();
